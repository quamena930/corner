// ---------------------------------------------------------------------------
// Corner Ledger - front-end behaviour
// This file only handles instant visual feedback (the live receipt preview,
// the clock, and the chart). All real business logic - calculating totals,
// tracking stock, storing sales - happens in Python on the server (app.py),
// exactly as required by the assignment.
// ---------------------------------------------------------------------------

function formatMoney(value) {
  return "GHS " + value.toFixed(2);
}

function updateReceiptPreview() {
  const select = document.getElementById("product");
  const quantityInput = document.getElementById("quantity");

  const selectedOption = select.options[select.selectedIndex];
  const hasProduct = selectedOption && selectedOption.value !== "";

  const productName = hasProduct ? selectedOption.value : "\u2014";
  const price = hasProduct ? parseFloat(selectedOption.dataset.price) : 0;
  const quantity = parseInt(quantityInput.value, 10) || 0;
  const lineTotal = price * quantity;

  document.getElementById("rcProduct").textContent = productName;
  document.getElementById("rcQty").textContent = quantity;
  document.getElementById("rcPrice").textContent = formatMoney(price || 0);
  document.getElementById("rcLine").textContent = formatMoney(lineTotal || 0);
  document.getElementById("rcTotal").textContent = formatMoney(lineTotal || 0);
}

document.getElementById("product").addEventListener("change", updateReceiptPreview);
document.getElementById("quantity").addEventListener("input", updateReceiptPreview);
updateReceiptPreview();

// ---------------------------------------------------------------------------
// Live clock in the top bar
// ---------------------------------------------------------------------------
function updateClock() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  const dateStr = now.toLocaleDateString(undefined, options);
  const timeStr = now.toLocaleTimeString();
  document.getElementById("liveDate").textContent = `${dateStr}  \u00b7  ${timeStr}`;
}
updateClock();
setInterval(updateClock, 1000);

// ---------------------------------------------------------------------------
// Sales-by-product chart (Chart.js), fed by data the server already computed
// ---------------------------------------------------------------------------
const chartCanvas = document.getElementById("salesChart");
if (chartCanvas && typeof CHART_LABELS !== "undefined" && CHART_LABELS.length > 0) {
  new Chart(chartCanvas, {
    type: "bar",
    data: {
      labels: CHART_LABELS,
      datasets: [{
        label: "Units sold",
        data: CHART_VALUES,
        backgroundColor: "#1B4B43",
        borderRadius: 4,
        maxBarThickness: 36,
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, ticks: { precision: 0 } }
      }
    }
  });
}
