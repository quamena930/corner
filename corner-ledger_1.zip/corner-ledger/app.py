"""
Corner Ledger - Simple Sales Recording Web Application
=========================================================
A small Flask web app that lets a shop owner record daily sales
and see totals, low-stock warnings, and a sales breakdown update
immediately in the browser.

This project intentionally sticks to the Python fundamentals covered
in class: variables, lists, dictionaries, and control flow (if/for/while).
There is no database - all data lives in plain Python lists and
dictionaries in memory, which reset each time the server restarts
(matching the assignment's "sales entered during the session" requirement).

Author: (your name here)
"""

from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime

app = Flask(__name__)
app.secret_key = "corner-ledger-secret-key"  # needed for flash messages

# ---------------------------------------------------------------------------
# DATA: Python fundamentals in action
# ---------------------------------------------------------------------------
# PRODUCTS is a list of dictionaries. Each dictionary represents one product
# the store sells, with its current price and how many units are in stock.
# Using a list-of-dicts is exactly the pattern covered in class for storing
# structured, "table-like" records with plain Python.
PRODUCTS = [
    {"name": "Rice (5kg bag)",     "price": 45.00, "stock": 18},
    {"name": "Cooking Oil (1L)",   "price": 22.50, "stock": 6},
    {"name": "Sugar (2kg)",        "price": 15.00, "stock": 30},
    {"name": "Bread (loaf)",       "price": 6.50,  "stock": 4},
    {"name": "Milk (1L)",          "price": 9.00,  "stock": 12},
    {"name": "Eggs (tray of 30)",  "price": 28.00, "stock": 9},
    {"name": "Soap (bar)",         "price": 4.00,  "stock": 40},
    {"name": "Bottled Water (1.5L)", "price": 3.50, "stock": 2},
]

# LOW_STOCK_THRESHOLD is a simple variable used to decide when to warn the
# shop owner that a product is running low. Anything at or below this
# number of units triggers an alert on the dashboard.
LOW_STOCK_THRESHOLD = 5

# SALES is the list that stores every sale recorded during this session.
# Each sale is a dictionary: {id, product, quantity, price, total, time}
SALES = []

# next_sale_id is a simple counter variable used to give each sale a unique id.
next_sale_id = 1


# ---------------------------------------------------------------------------
# HELPER FUNCTIONS (control flow: for-loops and if/else statements)
# ---------------------------------------------------------------------------

def find_product(name):
    """Loop through PRODUCTS and return the matching product dict, or None."""
    for product in PRODUCTS:
        if product["name"] == name:
            return product
    return None


def calculate_total(quantity, price):
    """Multiply quantity by unit price to get the line total for a sale."""
    return round(quantity * price, 2)


def get_daily_total():
    """Add up the total value of every sale recorded so far."""
    total = 0.0
    for sale in SALES:
        total += sale["total"]
    return round(total, 2)


def get_low_stock_products():
    """Return a list of products whose stock has fallen to/below the threshold."""
    low_stock = []
    for product in PRODUCTS:
        if product["stock"] <= LOW_STOCK_THRESHOLD:
            low_stock.append(product)
    return low_stock


def get_sales_by_product():
    """
    Build a dictionary summarising quantity sold per product, e.g.
    {"Rice (5kg bag)": 12, "Milk (1L)": 5, ...}
    Used to feed the bar chart on the dashboard.
    """
    summary = {}
    for sale in SALES:
        name = sale["product"]
        if name in summary:
            summary[name] += sale["quantity"]
        else:
            summary[name] = sale["quantity"]
    return summary


def get_top_product():
    """Return the name of the best-selling product by quantity, or None."""
    summary = get_sales_by_product()
    if not summary:
        return None
    # max() with a key function - another common control-flow tool from class
    return max(summary, key=summary.get)


# ---------------------------------------------------------------------------
# ROUTES
# ---------------------------------------------------------------------------

@app.route("/")
def dashboard():
    """Main dashboard: entry form, live stats, low-stock alerts, sales log."""
    context = {
        "products": PRODUCTS,
        "sales": list(reversed(SALES)),   # newest sale first
        "daily_total": get_daily_total(),
        "transaction_count": len(SALES),
        "low_stock_products": get_low_stock_products(),
        "top_product": get_top_product(),
        "chart_labels": list(get_sales_by_product().keys()),
        "chart_values": list(get_sales_by_product().values()),
    }
    return render_template("dashboard.html", **context)


@app.route("/add_sale", methods=["POST"])
def add_sale():
    """Handle the sale-entry form submission."""
    global next_sale_id

    product_name = request.form.get("product")
    quantity_raw = request.form.get("quantity")

    # --- basic validation using if/else control flow ---
    product = find_product(product_name)
    if product is None:
        flash("Please choose a valid product.", "error")
        return redirect(url_for("dashboard"))

    try:
        quantity = int(quantity_raw)
    except (TypeError, ValueError):
        flash("Quantity must be a whole number.", "error")
        return redirect(url_for("dashboard"))

    if quantity <= 0:
        flash("Quantity must be greater than zero.", "error")
        return redirect(url_for("dashboard"))

    if quantity > product["stock"]:
        flash(f'Only {product["stock"]} unit(s) of "{product["name"]}" left in stock.', "error")
        return redirect(url_for("dashboard"))

    # --- record the sale ---
    total = calculate_total(quantity, product["price"])
    sale = {
        "id": next_sale_id,
        "product": product["name"],
        "quantity": quantity,
        "price": product["price"],
        "total": total,
        "time": datetime.now().strftime("%I:%M %p"),
    }
    SALES.append(sale)
    next_sale_id += 1

    # reduce stock for the product that was sold
    product["stock"] -= quantity

    flash(f'Sale recorded: {quantity} x {product["name"]} = GHS {total:.2f}', "success")
    return redirect(url_for("dashboard"))


@app.route("/delete_sale/<int:sale_id>", methods=["POST"])
def delete_sale(sale_id):
    """Remove a sale from the log and restore the stock it used."""
    for sale in SALES:
        if sale["id"] == sale_id:
            product = find_product(sale["product"])
            if product is not None:
                product["stock"] += sale["quantity"]   # give the stock back
            SALES.remove(sale)
            flash("Sale entry deleted.", "success")
            break
    return redirect(url_for("dashboard"))


@app.route("/reset", methods=["POST"])
def reset_session():
    """Bonus feature: clear all sales recorded so far (start a new day)."""
    for product in PRODUCTS:
        pass  # stock levels intentionally kept as-is; only the sales log clears
    SALES.clear()
    global next_sale_id
    next_sale_id = 1
    flash("Sales log cleared for a new day.", "success")
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    app.run(debug=True)
