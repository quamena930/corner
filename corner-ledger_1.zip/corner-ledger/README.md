# Corner Ledger — Simple Sales Recording Web Application

A lightweight Flask web app that lets a small shop owner record daily sales
from a browser and see the day's numbers update immediately: total sales,
transaction count, top-selling product, low-stock warnings, and a live
sales-by-product chart.

Built around plain Python **lists and dictionaries** in memory (no database),
matching a course focused on Python fundamentals: variables, data types,
lists, dictionaries, and control flow.

## Features

- Sale-entry form (product + quantity), with an instantly-updating receipt
  preview calculated in JavaScript before you even submit
- Server-side total calculation and validation (Python does the real math)
- Live dashboard: today's total, transaction count, top seller
- Low-stock alert strip (flags any product at or below 5 units)
- Sales-by-product bar chart (Chart.js)
- Full sales log for the session, with delete support
- "Start New Day" button to clear the log (bonus feature)

## Project structure

```
corner-ledger/
├── app.py                  # Flask backend — all sales logic lives here
├── requirements.txt
├── templates/
│   └── dashboard.html      # single-page UI
└── static/
    ├── css/style.css       # ledger/receipt theme
    └── js/script.js        # live receipt preview, clock, chart
```

## Running it locally

```bash
pip install -r requirements.txt
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## Notes

- Product catalog and stock levels are seeded in `PRODUCTS` at the top of
  `app.py` — edit that list to match a real shop's inventory.
- All sales data is stored in memory and resets when the server restarts,
  matching the "sales entered during the session" requirement in the brief.
